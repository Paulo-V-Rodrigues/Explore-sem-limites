<h1 align="center"> Explore sem limites</h1>

<p align="center">
Desenvolvido por Ivan Barbosa.<br>
Layout UI/UX RocketSeat.
</p>

<p align="center">
  <a href="#-tecnologias">Tecnologias</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-projeto">Projeto</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-layout">Layout</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#memo-licença">Licença</a>
</p>
<p align="center">
🔖 Pagina
</p>

<p align="center">
Você pode visualizar e interagir com a pagina do projeto através 
<a href="https://ivanbs14.github.io/Page_Explore_sem_limites/">Click aqui </a>
</p>

<p align="center">
  Versão deskotp:<br>
  <img alt="License" src="./capa/Desktop - 1.png" width="70%" display="flex" gap="5px" ><br>
  Versão mobile:<br>
  <img alt="License" src="./capa//iPhone 14 Pro Max - 1.png" width="40%" display="flex" gap="5px" >

</p>

<br>

## 🚀 Tecnologias

Esse projeto foi desenvolvido com as seguintes tecnologias:

- HTML
- CSS
- Mobile First
- Git e Github

## 💻 Projeto

Land page de web.

## 🔖 Layout

O layout do projeto foi fornecido por
<p align="center">
https://www.rocketseat.com.br/
</p>

## :memo: Licença

Esse projeto está sob a licença MIT.

---
